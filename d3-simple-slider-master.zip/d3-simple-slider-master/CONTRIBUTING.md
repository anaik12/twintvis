The production source code does not make use of most modern syntax and runtime features. The exception is importing and exporting modules. This reflects the approach used by official d3 packages at the time this project was started.

With newer versions of d3 modules now starting to use newer features, e.g. [d3-array](https://github.com/d3/d3-array) we may introduce new language features but it would be a breaking change and require a new major version.
