export {
  sliderHorizontal,
  sliderVertical,
  sliderTop,
  sliderRight,
  sliderBottom,
  sliderLeft,
} from './slider.js';
